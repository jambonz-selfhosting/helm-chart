# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What This Is

Helm chart for deploying [jambonz](https://jambonz.org) (open-source CPaaS) on Kubernetes. Chart version 10.0.0, app version 10.0.3. Users clone this repo and install directly with `helm install`.

## Key Commands

```bash
# Validate templates render correctly
helm template jambonz . --namespace jambonz

# Lint the chart
helm lint .

# Dry-run install (checks against a cluster)
helm install jambonz . --namespace jambonz --dry-run

# Install
helm install jambonz . --namespace jambonz

# Upgrade after values changes
helm -n jambonz upgrade jambonz .

# Override values at install time
helm install jambonz . --namespace=jambonz --set "cloud=aws" --set "webapp.hostname=jambonz.example.com"
```

## Architecture

### VoIP Networking Constraint

SIP/RTP traffic cannot use standard Kubernetes networking or ingress controllers. SBC pods run on dedicated nodepools with **host networking** enabled. This is the fundamental architectural constraint that shapes the entire chart.

**Three required nodepools:**
- **Default** (standard networking) — all core services, databases, monitoring
- **SIP** (host networking) — `sbc-sip` DaemonSet for SIP signaling
- **RTP** (host networking) — `sbc-rtp` DaemonSet for media processing

### Component Groups

**SBC layer** (DaemonSets on host-networked nodes):
- `sbc-sip` — drachtio SIP server + sidecar (ports 5060/5061/8443)
- `sbc-rtp` — rtpengine media processor (ports 40000-60000)
- `sbc-call-router`, `sbc-inbound`, `sbc-outbound` — call routing Deployments on default pool

**Application layer** (Deployments on default pool):
- `api-server` — REST API
- `feature-server` — call control logic (contains embedded drachtio + freeswitch containers)
- `webapp` — admin portal UI

**Data layer** (StatefulSets on default pool):
- `mysql` — primary database (schema created by `db-create` Job, seeded by `db-seed` Job)
- `redis` — session/cache store
- `postgres` — Homer SIP capture backend

**Monitoring layer** (StatefulSets/Deployments on default pool):
- `influxdb` + `telegraf` — metrics
- `grafana` — dashboards
- `jaeger-collector` + `jaeger-query` — distributed tracing (optionally backed by `cassandra`)
- `homer` + `heplify-server` — SIP packet capture

### Ingress

Traefik is the ingress controller (installed separately). Four ingress resources route to: webapp, api-server, grafana, homer. TLS via cert-manager + Let's Encrypt is optional.

### Initialization Order

initContainers in application pods wait for MySQL to be ready. The `db-create` and `db-seed` Jobs must complete before app pods can start.

## Template Conventions

- Helper templates in `_helpers.tpl`: `common.labels` and `common.fullname`
- Secrets are base64-encoded in `values.yaml` and decoded in templates with `b64dec`
- Cloud-specific logic uses `{{ if eq .Values.cloud "aws" }}` conditionals
- SBC pods use `nodeSelector` and `tolerations` to target SIP/RTP nodepools (configured via `sbc.sip.nodeSelector` and `sbc.rtp.nodeSelector`)
- DaemonSets use `hostNetwork: true` for SBC pods

## Values Structure

The `cloud` field is required (`aws`, `gcp`, `azure`, `exoscale`). Required hostnames: `api.hostname`, `webapp.hostname`. Optional: `grafana.hostname`, `homer.hostname`.

Key sections: `global` (TLS, cassandra toggle, recordings toggle), `sbc` (node selectors, tolerations, EIP allocator for AWS), `drachtio`/`rtpengine` (SIP/RTP server images and config), service-specific blocks (`api`, `featureServer`, `webapp`), database blocks (`mysql`, `redis`, `postgres`), monitoring blocks (`grafana`, `influxdb`, `cassandra`, `jaeger*`).

Secrets that must be set per deployment: `db.mysql.secret`, `monitoring.postgres.secret`, `jwt.secret`, `drachtio.secret`.

## Cloud Provider Docs

Provider-specific terraform and DNS setup instructions are in `docs/`: `eks.md` (AWS), `gke.md` (GCP), `aks.md` (Azure), `sks.md` (Exoscale).
