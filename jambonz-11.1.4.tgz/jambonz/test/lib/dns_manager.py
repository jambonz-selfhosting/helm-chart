"""
DNS record management for Jambonz deployments.

Supports creating and deleting DNS A and CNAME records via DNS provider APIs.
Currently supports: DNSMadeEasy.

Based on the dns_manager.py from the terraform testing framework,
extended with CNAME support for AWS load balancers.
"""

import logging
import requests
from typing import List, Dict
from datetime import datetime
import hashlib
import hmac
import time
import socket


logger = logging.getLogger("jambonz-dns")


class DNSError(Exception):
    """Raised when DNS operations fail."""
    pass


class DNSManager:
    """
    DNS record manager supporting multiple providers.
    """

    def __init__(self, provider: str, config: dict, base_domain: str = None):
        self.provider = provider.lower()
        self.config = config

        if self.provider == 'dnsmadeeasy':
            self.api_key = config.get('api_key')
            self.secret = config.get('secret')
            self.api_url = config.get('api_url', 'https://api.dnsmadeeasy.com/V2.0')
            self.base_domain = base_domain or config.get('base_domain')

            if not self.api_key or not self.secret:
                raise DNSError("DNSMadeEasy requires api_key and secret in config")
            if not self.base_domain:
                raise DNSError("base_domain is required")
        else:
            raise DNSError(f"Unsupported DNS provider: {provider}")

    def create_record(self, subdomain: str, value: str, record_type: str = 'A', ttl: int = 300) -> Dict:
        """
        Create a DNS record, deleting any existing record with the same name first.

        Args:
            subdomain: Subdomain relative to base_domain (e.g., 'gcp', 'api.gcp')
            value: IP address (for A) or hostname (for CNAME)
            record_type: 'A' or 'CNAME'
            ttl: TTL in seconds

        Returns:
            Dictionary with record details
        """
        full_domain = f"{subdomain}.{self.base_domain}"
        logger.info(f"Creating {record_type} record: {full_domain} -> {value}")

        if self.provider == 'dnsmadeeasy':
            return self._create_dnsmadeeasy_record(subdomain, value, record_type, ttl)

        raise DNSError(f"Provider {self.provider} not implemented")

    def delete_record(self, record_id: str) -> bool:
        """Delete a DNS record by ID."""
        logger.info(f"Deleting DNS record: {record_id}")

        if self.provider == 'dnsmadeeasy':
            return self._delete_dnsmadeeasy_record(record_id)

        raise DNSError(f"Provider {self.provider} not implemented")

    def list_records(self, subdomain: str = None) -> List[Dict]:
        """List existing DNS records, optionally filtered by subdomain."""
        if self.provider == 'dnsmadeeasy':
            return self._list_dnsmadeeasy_records(subdomain)

        raise DNSError(f"Provider {self.provider} not implemented")

    def _create_dnsmadeeasy_record(self, subdomain: str, value: str, record_type: str, ttl: int) -> Dict:
        domain_id = self._get_domain_id(self.base_domain)
        if not domain_id:
            raise DNSError(f"Domain not found: {self.base_domain}")

        # Delete any existing record with the same name (regardless of type)
        existing_records = self._list_dnsmadeeasy_records(subdomain)
        for record in existing_records:
            if record['name'] == subdomain:
                logger.info(f"Deleting existing {record['type']} record: {subdomain}.{self.base_domain}")
                self._delete_dnsmadeeasy_record(record['id'])

        # Create new record
        headers = self._generate_dnsmadeeasy_headers()
        url = f"{self.api_url}/dns/managed/{domain_id}/records"

        data = {
            "name": subdomain,
            "type": record_type,
            "value": value,
            "ttl": ttl
        }

        response = requests.post(url, headers=headers, json=data)

        if response.status_code not in [200, 201]:
            raise DNSError(f"Failed to create record: {response.status_code} - {response.text}")

        result = response.json()
        return {
            'id': result.get('id'),
            'name': subdomain,
            'type': record_type,
            'value': value,
            'ttl': ttl
        }

    def _delete_dnsmadeeasy_record(self, record_id: str) -> bool:
        domain_id = self._get_domain_id(self.base_domain)
        if not domain_id:
            raise DNSError(f"Domain not found: {self.base_domain}")

        headers = self._generate_dnsmadeeasy_headers()
        url = f"{self.api_url}/dns/managed/{domain_id}/records/{record_id}"

        response = requests.delete(url, headers=headers)

        if response.status_code not in [200, 204]:
            raise DNSError(f"Failed to delete record {record_id}: {response.status_code} - {response.text}")

        return True

    def _list_dnsmadeeasy_records(self, subdomain: str = None) -> List[Dict]:
        domain_id = self._get_domain_id(self.base_domain)
        if not domain_id:
            raise DNSError(f"Domain not found: {self.base_domain}")

        headers = self._generate_dnsmadeeasy_headers()
        url = f"{self.api_url}/dns/managed/{domain_id}/records"

        response = requests.get(url, headers=headers)

        if response.status_code != 200:
            raise DNSError(f"Failed to list records: {response.status_code} - {response.text}")

        result = response.json()
        records = result.get('data', [])

        if subdomain:
            records = [
                r for r in records
                if r.get('name') == subdomain or r.get('name', '').endswith(f".{subdomain}")
            ]

        return [
            {
                'id': r.get('id'),
                'name': r.get('name'),
                'type': r.get('type'),
                'value': r.get('value'),
                'ttl': r.get('ttl')
            }
            for r in records
        ]

    def _get_domain_id(self, domain: str) -> str:
        headers = self._generate_dnsmadeeasy_headers()
        url = f"{self.api_url}/dns/managed/name?domainname={domain}"

        response = requests.get(url, headers=headers)

        if response.status_code != 200:
            raise DNSError(f"Failed to get domain ID for {domain}: {response.status_code} - {response.text}")

        result = response.json()
        domain_id = result.get('id')

        if not domain_id:
            raise DNSError(f"Domain {domain} not found in DNSMadeEasy")

        return str(domain_id)

    def _generate_dnsmadeeasy_headers(self) -> dict:
        timestamp = datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')

        hmac_hash = hmac.new(
            self.secret.encode('utf-8'),
            timestamp.encode('utf-8'),
            hashlib.sha1
        ).hexdigest()

        return {
            'x-dnsme-apiKey': self.api_key,
            'x-dnsme-requestDate': timestamp,
            'x-dnsme-hmac': hmac_hash,
            'Content-Type': 'application/json'
        }


def extract_base_domain(url: str) -> str:
    """Extract base domain from a URL like 'gcp.jambonz.io' -> 'jambonz.io'."""
    parts = url.split('.')
    if len(parts) >= 2:
        return '.'.join(parts[-2:])
    return url


def extract_subdomain(url: str) -> str:
    """Extract subdomain from a URL like 'gcp.jambonz.io' -> 'gcp'."""
    parts = url.split('.')
    if len(parts) >= 3:
        return '.'.join(parts[:-2])
    return url.split('.')[0] if '.' in url else url


def wait_for_dns_propagation(domain: str, expected_value: str, timeout: int = 120, interval: int = 5) -> bool:
    """Wait for a DNS record to propagate. Works for A records (resolves to IP)."""
    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            resolved_ip = socket.gethostbyname(domain)
            if resolved_ip == expected_value:
                elapsed = int(time.time() - start_time)
                print(f"  DNS propagated in {elapsed}s")
                return True
        except socket.gaierror:
            pass
        time.sleep(interval)

    raise DNSError(f"DNS propagation timeout after {timeout}s for {domain}")
