#!/usr/bin/env python3.11
"""
DNS setup for jambonz helm chart deployments.

Detects the cloud provider and baseUrl from the helm release, queries kubectl
for the traefik load balancer address, and creates DNS records via DNSMadeEasy.

Usage:
    # Create DNS records (auto-detects cloud, baseUrl, and LB address)
    python test/setup-dns.py create --config test/dns-config.yaml

    # Delete DNS records
    python test/setup-dns.py delete --config test/dns-config.yaml

    # List existing records
    python test/setup-dns.py list --config test/dns-config.yaml

    # Issue TLS certs via DNS-01 challenge (when HTTP-01 fails)
    python test/setup-dns.py issue-certs --config test/dns-config.yaml
"""

import sys
import json
import subprocess
import time
import click
from pathlib import Path

# Add lib directory to path
sys.path.insert(0, str(Path(__file__).parent / "lib"))

from config_loader import load_config
from dns_manager import (
    DNSManager,
    DNSError,
    wait_for_dns_propagation,
    extract_base_domain,
    extract_subdomain
)


def get_helm_values(release: str, namespace: str) -> dict:
    """Get values from a deployed helm release."""
    try:
        result = subprocess.run(
            ['helm', 'get', 'values', release, '-n', namespace, '-o', 'json'],
            capture_output=True, text=True, check=True
        )
        return json.loads(result.stdout)
    except subprocess.CalledProcessError as e:
        print(f"Failed to get helm values: {e.stderr.strip()}")
        sys.exit(1)
    except json.JSONDecodeError:
        print("Failed to parse helm values as JSON")
        sys.exit(1)


def get_traefik_lb_address(namespace: str) -> dict:
    """
    Get the traefik load balancer ingress address.

    Returns dict with either 'hostname' (AWS) or 'ip' (GCP/Azure/Exoscale).
    """
    try:
        result = subprocess.run(
            ['kubectl', '-n', namespace, 'get', 'svc', 'traefik',
             '-o', 'jsonpath={.status.loadBalancer.ingress[0]}'],
            capture_output=True, text=True, check=True
        )
        output = result.stdout.strip()
        if not output:
            print("Traefik service has no load balancer ingress yet. Is it still provisioning?")
            sys.exit(1)
        return json.loads(output)
    except subprocess.CalledProcessError as e:
        print(f"Failed to get traefik service: {e.stderr.strip()}")
        sys.exit(1)
    except json.JSONDecodeError:
        print(f"Failed to parse traefik ingress: {result.stdout}")
        sys.exit(1)


@click.group()
def cli():
    """DNS record management for jambonz helm chart deployments."""
    pass


@cli.command()
@click.option('--config', default='test/dns-config.yaml', type=click.Path(exists=True),
              help='Path to DNS config file')
@click.option('--namespace', default='jambonz', help='Kubernetes namespace')
@click.option('--release', default='jambonz', help='Helm release name')
@click.option('--ttl', default=300, type=int, help='DNS TTL in seconds')
@click.option('--wait', is_flag=True, help='Wait for DNS propagation after creating records')
def create(config, namespace, release, ttl, wait):
    """Create DNS records for a jambonz deployment."""
    print("=" * 70)
    print("DNS Record Creation")
    print("=" * 70)
    print()

    # Step 1: Get cloud provider and baseUrl from helm release
    print("Querying helm release...")
    values = get_helm_values(release, namespace)
    cloud = values.get('cloud')
    base_url = values.get('baseUrl')

    if not cloud:
        print("'cloud' not set in helm values")
        sys.exit(1)
    if not base_url:
        print("'baseUrl' not set in helm values")
        sys.exit(1)

    print(f"  Cloud: {cloud}")
    print(f"  Base URL: {base_url}")
    print()

    # Step 2: Get load balancer address
    print("Querying traefik load balancer...")
    ingress = get_traefik_lb_address(namespace)

    if cloud == 'aws':
        lb_address = ingress.get('hostname')
        # Trailing dot makes it a FQDN so DNSMadeEasy doesn't append the zone
        if lb_address and not lb_address.endswith('.'):
            lb_address += '.'
        record_type = 'CNAME'
    else:
        lb_address = ingress.get('ip')
        record_type = 'A'

    if not lb_address:
        print(f"Could not determine load balancer address from ingress: {ingress}")
        sys.exit(1)

    print(f"  Load balancer: {lb_address}")
    print(f"  Record type: {record_type}")
    print()

    # Step 3: Parse baseUrl into base_domain and subdomain
    base_domain = extract_base_domain(base_url)
    subdomain = extract_subdomain(base_url)

    print(f"  DNS zone: {base_domain}")
    print(f"  Subdomain: {subdomain}")
    print()

    # Step 4: Load DNS config and initialize manager
    try:
        config_data = load_config(config)
        dns_config = config_data.get('dns', {})
        if not dns_config:
            print("No 'dns' section found in config file")
            sys.exit(1)

        provider = dns_config.get('provider', 'dnsmadeeasy')
        dns = DNSManager(provider=provider, config=dns_config, base_domain=base_domain)
        print(f"DNS provider: {provider}")
        print()
    except DNSError as e:
        print(f"Failed to initialize DNS manager: {e}")
        sys.exit(1)

    # Step 5: Define and create records
    # subdomain is the part before the base domain (e.g., 'eks' from 'eks.jambonz.io')
    # The 4 hostnames are: {subdomain}, api.{subdomain}, grafana.{subdomain}, homer.{subdomain}
    records_to_create = [
        (subdomain, lb_address),
        (f"api.{subdomain}", lb_address),
        (f"grafana.{subdomain}", lb_address),
        (f"homer.{subdomain}", lb_address),
    ]

    print(f"Creating {len(records_to_create)} {record_type} records...")
    print()

    created_records = []
    failed = 0

    for record_subdomain, value in records_to_create:
        full_domain = f"{record_subdomain}.{base_domain}"
        print(f"  {full_domain} -> {value}")

        try:
            record = dns.create_record(
                subdomain=record_subdomain,
                value=value,
                record_type=record_type,
                ttl=ttl
            )
            created_records.append(record)
            print(f"    created (ID: {record.get('id', 'N/A')})")
        except DNSError as e:
            print(f"    FAILED: {e}")
            failed += 1

    print()
    print("=" * 70)
    print(f"Summary: {len(created_records)} created, {failed} failed")
    print("=" * 70)

    # Wait for propagation if requested (only meaningful for A records)
    if wait and created_records and record_type == 'A':
        print()
        print("Waiting for DNS propagation...")
        for record_subdomain, value in records_to_create[:1]:
            full_domain = f"{record_subdomain}.{base_domain}"
            try:
                wait_for_dns_propagation(full_domain, value, timeout=120)
            except DNSError as e:
                print(f"  {e}")

    print()
    sys.exit(0 if failed == 0 else 1)


@cli.command()
@click.option('--config', default='test/dns-config.yaml', type=click.Path(exists=True),
              help='Path to DNS config file')
@click.option('--namespace', default='jambonz', help='Kubernetes namespace')
@click.option('--release', default='jambonz', help='Helm release name')
@click.option('--yes', is_flag=True, help='Skip confirmation')
def delete(config, namespace, release, yes):
    """Delete DNS records for a jambonz deployment."""
    print("=" * 70)
    print("DNS Record Deletion")
    print("=" * 70)
    print()

    # Get baseUrl from helm release
    print("Querying helm release...")
    values = get_helm_values(release, namespace)
    base_url = values.get('baseUrl')

    if not base_url:
        print("'baseUrl' not set in helm values")
        sys.exit(1)

    base_domain = extract_base_domain(base_url)
    subdomain = extract_subdomain(base_url)

    print(f"  Base URL: {base_url}")
    print(f"  DNS zone: {base_domain}")
    print(f"  Subdomain: {subdomain}")
    print()

    if not yes:
        response = input(f"Delete all DNS records for '{subdomain}' in {base_domain}? (yes/no): ")
        if response.lower() not in ['yes', 'y']:
            print("Cancelled.")
            sys.exit(0)

    try:
        config_data = load_config(config)
        dns_config = config_data.get('dns', {})
        if not dns_config:
            print("No 'dns' section found in config file")
            sys.exit(1)

        provider = dns_config.get('provider', 'dnsmadeeasy')
        dns = DNSManager(provider=provider, config=dns_config, base_domain=base_domain)

        records = dns.list_records(subdomain=subdomain)

        if not records:
            print("No records found to delete.")
            sys.exit(0)

        print(f"Deleting {len(records)} record(s)...")
        print()

        deleted = 0
        failed = 0

        for record in records:
            record_name = record.get('name', 'N/A')
            record_id = record.get('id')
            print(f"  Deleting: {record_name}.{base_domain}")

            try:
                dns.delete_record(record_id)
                print(f"    deleted")
                deleted += 1
            except DNSError as e:
                print(f"    FAILED: {e}")
                failed += 1

        print()
        print(f"Summary: {deleted} deleted, {failed} failed")

    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

    print()


@cli.command('list')
@click.option('--config', default='test/dns-config.yaml', type=click.Path(exists=True),
              help='Path to DNS config file')
@click.option('--namespace', default='jambonz', help='Kubernetes namespace')
@click.option('--release', default='jambonz', help='Helm release name')
def list_records(config, namespace, release):
    """List existing DNS records."""
    print("=" * 70)
    print("DNS Records")
    print("=" * 70)
    print()

    # Get baseUrl from helm release
    print("Querying helm release...")
    values = get_helm_values(release, namespace)
    base_url = values.get('baseUrl')

    if not base_url:
        print("'baseUrl' not set in helm values")
        sys.exit(1)

    base_domain = extract_base_domain(base_url)
    subdomain = extract_subdomain(base_url)

    print(f"  Base URL: {base_url}")
    print(f"  DNS zone: {base_domain}")
    print(f"  Filtering by: {subdomain}")
    print()

    try:
        config_data = load_config(config)
        dns_config = config_data.get('dns', {})
        if not dns_config:
            print("No 'dns' section found in config file")
            sys.exit(1)

        provider = dns_config.get('provider', 'dnsmadeeasy')
        dns = DNSManager(provider=provider, config=dns_config, base_domain=base_domain)

        records = dns.list_records(subdomain=subdomain)

        if records:
            print(f"Found {len(records)} record(s):")
            print()
            for record in records:
                rtype = record.get('type', '?')
                name = record.get('name', 'N/A')
                value = record.get('value', 'N/A')
                ttl = record.get('ttl', 'N/A')
                print(f"  {rtype:5s}  {name}.{base_domain} -> {value}  (TTL: {ttl})")
        else:
            print("No records found.")

    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

    print()


def get_pending_certs(namespace: str) -> list:
    """Get list of Certificate resources that are not Ready."""
    try:
        result = subprocess.run(
            ['kubectl', '-n', namespace, 'get', 'certificate', '-o', 'json'],
            capture_output=True, text=True, check=True
        )
        data = json.loads(result.stdout)
        pending = []
        for item in data.get('items', []):
            name = item['metadata']['name']
            conditions = item.get('status', {}).get('conditions', [])
            ready = any(
                c.get('type') == 'Ready' and c.get('status') == 'True'
                for c in conditions
            )
            if not ready:
                # Get the domain from the spec
                dns_names = item.get('spec', {}).get('dnsNames', [])
                secret_name = item.get('spec', {}).get('secretName', name)
                if dns_names:
                    pending.append({
                        'name': name,
                        'domain': dns_names[0],
                        'secret_name': secret_name,
                    })
        return pending
    except subprocess.CalledProcessError as e:
        print(f"Failed to get certificates: {e.stderr.strip()}")
        return []


def issue_cert_dns01(domains: list, email: str, dns: 'DNSManager', base_domain: str,
                     staging: bool = False) -> tuple:
    """
    Issue a certificate using ACME DNS-01 challenge via DNSMadeEasy.

    Returns (cert_pem, key_pem) as strings.
    """
    import josepy as jose
    from cryptography.hazmat.primitives.asymmetric import rsa, ec
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives import serialization
    from cryptography import x509
    from cryptography.x509.oid import NameOID
    from cryptography.hazmat.primitives.hashes import SHA256
    from acme import client as acme_client
    from acme import messages, challenges

    if staging:
        directory_url = 'https://acme-staging-v02.api.letsencrypt.org/directory'
    else:
        directory_url = 'https://acme-v02.api.letsencrypt.org/directory'

    # Generate account key
    account_key_raw = rsa.generate_private_key(
        public_exponent=65537, key_size=2048, backend=default_backend()
    )
    account_key = jose.JWKRSA(key=account_key_raw)

    # Create ACME client
    net = acme_client.ClientNetwork(account_key)
    directory = messages.Directory.from_json(net.get(directory_url).json())
    acme = acme_client.ClientV2(directory, net)

    # Register account
    registration = messages.NewRegistration.from_data(
        email=email, terms_of_service_agreed=True
    )
    acme.new_account(registration)

    # Generate CSR key and build CSR using cryptography lib
    csr_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
    csr_key_pem = csr_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption()
    )

    csr_builder = x509.CertificateSigningRequestBuilder()
    csr_builder = csr_builder.subject_name(
        x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, domains[0])])
    )
    csr_builder = csr_builder.add_extension(
        x509.SubjectAlternativeName([x509.DNSName(d) for d in domains]),
        critical=False,
    )
    csr_obj = csr_builder.sign(csr_key, SHA256(), default_backend())
    csr_pem = csr_obj.public_bytes(serialization.Encoding.PEM)

    # Create order
    order = acme.new_order(csr_pem)

    # Process each authorization
    txt_records_to_cleanup = []

    try:
        for authz in order.authorizations:
            domain = authz.body.identifier.value
            print(f"  Processing challenge for {domain}...")

            # Find DNS-01 challenge
            dns_challenge = None
            for challenge in authz.body.challenges:
                if isinstance(challenge.chall, challenges.DNS01):
                    dns_challenge = challenge
                    break

            if not dns_challenge:
                raise Exception(f"No DNS-01 challenge found for {domain}")

            # Get the validation value
            validation = dns_challenge.validation(account_key)

            # Create TXT record: _acme-challenge.{domain}
            # The subdomain relative to base_domain
            if domain.endswith(f'.{base_domain}'):
                rel_subdomain = domain[:-len(f'.{base_domain}')]
            else:
                rel_subdomain = domain

            txt_subdomain = f"_acme-challenge.{rel_subdomain}"

            print(f"    Creating TXT record: {txt_subdomain}.{base_domain}")
            print(f"    Value: {validation}")

            record = dns.create_record(
                subdomain=txt_subdomain,
                value=validation,
                record_type='TXT',
                ttl=60
            )
            txt_records_to_cleanup.append(record.get('id'))

            # Wait for DNS propagation using dig
            print(f"    Waiting for DNS propagation...")
            challenge_domain = f"_acme-challenge.{domain}"
            propagated = False
            for attempt in range(24):  # up to 2 minutes
                try:
                    dig_result = subprocess.run(
                        ['dig', '+short', 'TXT', challenge_domain],
                        capture_output=True, text=True, timeout=10
                    )
                    txt_values = dig_result.stdout.strip().replace('"', '')
                    if validation in txt_values:
                        print(f"    DNS propagated after {(attempt + 1) * 5}s")
                        propagated = True
                        break
                except Exception:
                    pass
                time.sleep(5)
            if not propagated:
                print(f"    Timed out waiting, proceeding anyway...")

            # Answer the challenge
            print(f"    Answering challenge...")
            acme.answer_challenge(dns_challenge, dns_challenge.response(account_key))

        # Finalize the order
        print(f"  Finalizing order...")
        order = acme.poll_and_finalize(order)

        # Extract certificate
        fullchain_pem = order.fullchain_pem
        key_pem = csr_key_pem.decode()

        return fullchain_pem, key_pem

    finally:
        # Cleanup TXT records
        print(f"  Cleaning up TXT records...")
        for record_id in txt_records_to_cleanup:
            try:
                dns.delete_record(record_id)
            except Exception as e:
                print(f"    Warning: failed to delete TXT record {record_id}: {e}")


def store_tls_secret(namespace: str, secret_name: str, cert_pem: str, key_pem: str):
    """Create or update a K8s TLS secret."""
    import base64
    cert_b64 = base64.b64encode(cert_pem.encode()).decode()
    key_b64 = base64.b64encode(key_pem.encode()).decode()

    secret_json = json.dumps({
        "apiVersion": "v1",
        "kind": "Secret",
        "metadata": {
            "name": secret_name,
            "namespace": namespace,
        },
        "type": "kubernetes.io/tls",
        "data": {
            "tls.crt": cert_b64,
            "tls.key": key_b64,
        }
    })

    result = subprocess.run(
        ['kubectl', 'apply', '-f', '-'],
        input=secret_json, capture_output=True, text=True
    )
    if result.returncode != 0:
        raise Exception(f"Failed to create secret: {result.stderr.strip()}")


@cli.command('issue-certs')
@click.option('--config', default='test/dns-config.yaml', type=click.Path(exists=True),
              help='Path to DNS config file')
@click.option('--namespace', default='jambonz', help='Kubernetes namespace')
@click.option('--release', default='jambonz', help='Helm release name')
@click.option('--email', default='admin@jambonz.org', help='Email for Let\'s Encrypt account')
@click.option('--staging', is_flag=True, help='Use Let\'s Encrypt staging (for testing)')
@click.option('--all-certs', is_flag=True, help='Issue all certs, not just pending ones')
def issue_certs(config, namespace, release, email, staging, all_certs):
    """Issue TLS certificates using DNS-01 challenge (when HTTP-01 fails)."""
    print("=" * 70)
    print("TLS Certificate Issuance (DNS-01)")
    print("=" * 70)
    print()

    if staging:
        print("  ** Using Let's Encrypt STAGING environment **")
        print()

    # Get baseUrl from helm release
    print("Querying helm release...")
    values = get_helm_values(release, namespace)
    base_url = values.get('baseUrl')

    if not base_url:
        print("'baseUrl' not set in helm values")
        sys.exit(1)

    base_domain = extract_base_domain(base_url)
    subdomain = extract_subdomain(base_url)

    print(f"  Base URL: {base_url}")
    print(f"  DNS zone: {base_domain}")
    print()

    # Load DNS config
    try:
        config_data = load_config(config)
        dns_config = config_data.get('dns', {})
        if not dns_config:
            print("No 'dns' section found in config file")
            sys.exit(1)

        provider = dns_config.get('provider', 'dnsmadeeasy')
        dns = DNSManager(provider=provider, config=dns_config, base_domain=base_domain)
    except DNSError as e:
        print(f"Failed to initialize DNS manager: {e}")
        sys.exit(1)

    # Find certs that need issuing
    if all_certs:
        # Build the list from the standard 4 hostnames
        certs_to_issue = [
            {'name': 'jambonz-webapp-tls', 'domain': base_url, 'secret_name': 'jambonz-webapp-tls'},
            {'name': 'jambonz-api-tls', 'domain': f'api.{base_url}', 'secret_name': 'jambonz-api-tls'},
            {'name': 'jambonz-grafana-tls', 'domain': f'grafana.{base_url}', 'secret_name': 'jambonz-grafana-tls'},
            {'name': 'jambonz-homer-tls', 'domain': f'homer.{base_url}', 'secret_name': 'jambonz-homer-tls'},
        ]
    else:
        certs_to_issue = get_pending_certs(namespace)

    if not certs_to_issue:
        print("All certificates are Ready. Nothing to do.")
        print("  (Use --all-certs to re-issue all certificates)")
        sys.exit(0)

    print(f"Certificates to issue: {len(certs_to_issue)}")
    for cert in certs_to_issue:
        print(f"  - {cert['domain']} (secret: {cert['secret_name']})")
    print()

    issued = 0
    failed = 0

    for cert in certs_to_issue:
        domain = cert['domain']
        secret_name = cert['secret_name']

        print(f"Issuing certificate for {domain}...")
        try:
            cert_pem, key_pem = issue_cert_dns01(
                domains=[domain],
                email=email,
                dns=dns,
                base_domain=base_domain,
                staging=staging,
            )

            print(f"  Storing as K8s secret '{secret_name}'...")
            store_tls_secret(namespace, secret_name, cert_pem, key_pem)
            print(f"  Done!")
            print()
            issued += 1
        except Exception as e:
            print(f"  FAILED: {e}")
            print()
            failed += 1

    print("=" * 70)
    print(f"Summary: {issued} issued, {failed} failed")
    print("=" * 70)
    print()
    sys.exit(0 if failed == 0 else 1)


if __name__ == '__main__':
    cli()
